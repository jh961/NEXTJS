export const DEFAULT_LANGUAGE = "es-ES"
